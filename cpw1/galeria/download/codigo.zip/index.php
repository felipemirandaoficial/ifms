<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
	<link rel="stylesheet" href="css/styles.css">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Galeria de Outono</title>
</head>
<body>
<div class="inicio">
  <h1>Galeria de Outono</h1>
</div>
<div id='info'>
	<ul>
		<p>Baixar Codigo PHP/CSS</p>
		<a target='_blank' href='download/codigo.zip'> <img id='down' src="img/download.png" alt="Imagem de download"> </a>
	</ul>
</div>

<div class="linha">
    <?php
    $pastaImagens = '../../back/aleatorio/';
    $tiposPermitidos = ['jpg', 'jpeg', 'png', 'gif'];
    $arquivos = scandir($pastaImagens);
    $contadorImagens = 0;
    foreach ($arquivos as $arquivo) {
        $extensao = pathinfo($arquivo, PATHINFO_EXTENSION);
        if (in_array($extensao, $tiposPermitidos)) {
            if ($contadorImagens % 4 === 0) {
                echo '<div class="coluna">';
            }
            echo "<a target='_blank' href='$pastaImagens$arquivo'>" . '<img src="' . $pastaImagens . $arquivo . '" alt="Imagem de ' . $arquivo . '"> </a>';
            if ($contadorImagens % 4 === 3) {
                echo '</div>';
            }
            $contadorImagens++;
        }
    }
    if ($contadorImagens % 4 !== 0) {
        echo '</div>';
    }
    ?>
</div>

</body>
</html>