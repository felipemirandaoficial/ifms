<?php
echo 'Tudo OK por aqui!';




?>
